function loadTask(task) {
    window.location.href=`/templates/tasks/${task}.html`
}